import sys
import os
import pytest

module_dir = os.path.dirname(os.path.abspath(__file__))
project_dir = os.path.abspath(os.path.join(module_dir, '..'))
sys.path.append(project_dir)

from heapsort import heap_sort, max_heap_sort, custom_heap_sort

# Test cases for the heap_sort function
def test_heap_sort_empty_list():
    assert heap_sort([]) == []

def test_heap_sort_sorted_list():
    assert heap_sort([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]

def test_heap_sort_reverse_sorted_list():
    assert heap_sort([5, 4, 3, 2, 1]) == [1, 2, 3, 4, 5]

# Test cases for the max_heap_sort function
def test_max_heap_sort_empty_list():
    assert max_heap_sort([]) == []

def test_max_heap_sort_sorted_list():
    assert max_heap_sort([5, 4, 3, 2, 1]) == [5, 4, 3, 2, 1]

def test_max_heap_sort_reverse_sorted_list():
    assert max_heap_sort([1, 2, 3, 4, 5]) == [5, 4, 3, 2, 1]

# Test cases for the custom_heap_sort function
def test_custom_heap_sort_empty_list():
    assert custom_heap_sort([], sort='min') == []

def test_custom_heap_sort_sorted_list_min_heap():
    assert custom_heap_sort([1, 2, 3, 4, 5], sort='min') == [1, 2, 3, 4, 5]

def test_custom_heap_sort_sorted_list_max_heap():
    assert custom_heap_sort([1, 2, 3, 4, 5], sort='max') == [5, 4, 3, 2, 1]