#Pyguin test cases converted from mergesort/DYNAMOSA/seed_1706/test_mergesort.py
import mergesort as module_0

def test_case_0():
    bytes_0 = b'\xe5Z\xe4\xdep\xa7\xe2\x1do\r&\xfb\x0eDC\xae)\xed\x99)'
    var_0 = module_0.mergesort(bytes_0)
