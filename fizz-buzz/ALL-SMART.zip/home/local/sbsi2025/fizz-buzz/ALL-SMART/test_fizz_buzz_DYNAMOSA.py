#Pyguin test cases converted from fizz-buzz/DYNAMOSA/seed_1706/test_fizz_buzz.py
import pytest
import fizz_buzz as module_0

def test_case_0():
    bool_0 = True
    var_0 = module_0.fizz_buzz(bool_0)
    bytes_0 = b'\x10\xf7_m\x97\xbeb\xf3.\xabc'

def test_case_1():
    int_0 = -870
    var_0 = module_0.fizz_buzz(int_0)

def test_case_2():
    float_0 = -335.788283

def test_case_3():
    int_0 = 1415
    var_0 = module_0.fizz_buzz(int_0)
    var_1 = module_0.fizz_buzz(int_0)
