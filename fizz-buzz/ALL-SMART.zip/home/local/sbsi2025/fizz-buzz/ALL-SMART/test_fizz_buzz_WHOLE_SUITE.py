#Pyguin test cases converted from fizz-buzz/WHOLE_SUITE/seed_1706/test_fizz_buzz.py
import pytest
import fizz_buzz as module_0
import builtins as module_1

def test_case_0():
    int_0 = 1415
    var_0 = module_0.fizz_buzz(int_0)
    var_1 = module_0.fizz_buzz(int_0)

def test_case_1():
    bytes_0 = b'`\x0c\xb5\x99\xd284\x1c\xf9\x1aR\xd7\x18\xed.+\x88\xad\xd9\xe4'

def test_case_2():
    int_0 = -1425
    var_0 = module_0.fizz_buzz(int_0)
    var_1 = module_0.fizz_buzz(int_0)

def test_case_3():
    object_0 = module_1.object()

def test_case_4():
    bytes_0 = b'\xee{{\xd8\x8e\r\x9c\xca'
    list_0 = [bytes_0, bytes_0]

def test_case_5():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}

def test_case_6():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}

def test_case_7():
    float_0 = -668.911821

def test_case_8():
    str_0 = 'mCj(m&rYtS2}m*#26mz1'
