#Pyguin test cases converted from priority-queue2/MIO/seed_1706/test_priority_queue2.py
import pytest
import priority_queue2 as module_0

def test_case_0():
    priority_q_0 = module_0.PriorityQ()
    var_0 = priority_q_0.insert(priority_q_0)
    var_1 = priority_q_0.pop()
    assert f'{type(var_1).__module__}.{type(var_1).__qualname__}' == 'priority_queue2.PriorityQ'

def test_case_1():
    priority_q_0 = module_0.PriorityQ()
    var_0 = priority_q_0.peek()
    var_1 = priority_q_0.insert(var_0)

def test_case_2():
    priority_q_0 = module_0.PriorityQ()
    var_0 = priority_q_0.peek()

def test_case_3():
    priority_q_0 = module_0.PriorityQ()

def test_case_4():
    priority_q_0 = module_0.PriorityQ()
    var_0 = priority_q_0.insert(priority_q_0)
