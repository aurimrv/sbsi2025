#Pyguin test cases converted from stack/WHOLE_SUITE/seed_1706/test_stack.py
import stack as module_0
import linked_list2 as module_1

def test_case_0():
    stack_0 = module_0.Stack()
    set_0 = {stack_0, stack_0}
    stack_1 = module_0.Stack(set_0)
    dict_0 = {}
    linked_list_0 = module_1.LinkedList()
    var_0 = linked_list_0.remove(dict_0)
    var_0.push(var_0)

def test_case_1():
    complex_0 = 4326.2632 - 1699.189j
    stack_0 = module_0.Stack(complex_0)
    stack_1 = module_0.Stack()
    stack_2 = module_0.Stack()
    var_0 = stack_1.push(complex_0)
    stack_2.pop()

def test_case_2():
    stack_0 = module_0.Stack()
    stack_0.pop()

def test_case_3():
    float_0 = 1483.07407
    list_0 = [float_0, float_0, float_0]
    linked_list_0 = module_1.LinkedList()
    var_0 = linked_list_0.size()
    var_0.push(list_0)

def test_case_4():
    pass

def test_case_5():
    stack_0 = module_0.Stack()
    stack_0.pop()

def test_case_6():
    stack_0 = module_0.Stack()
    stack_1 = module_0.Stack()
    stack_2 = module_0.Stack()
    var_0 = stack_2.push(stack_2)
    stack_3 = module_0.Stack()
    stack_4 = module_0.Stack()
    var_1 = stack_2.pop()
    var_1.push(var_1)

def test_case_7():
    stack_0 = module_0.Stack()
    stack_1 = module_0.Stack()
    stack_2 = module_0.Stack()
    stack_3 = module_0.Stack()
    var_0 = stack_3.push(stack_1)
    var_1 = stack_0.push(var_0)
    var_2 = stack_0.pop()
    stack_4 = module_0.Stack()
    var_3 = stack_2.push(stack_2)
    var_4 = stack_0.push(var_3)
    var_4.pop()
