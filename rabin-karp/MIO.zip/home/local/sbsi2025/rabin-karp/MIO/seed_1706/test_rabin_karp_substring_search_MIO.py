#Pyguin test cases converted from rabin-karp/MIO/seed_1706/test_rabin_karp_substring_search.py
import rabin_karp_substring_search as module_0

def test_case_0():
    str_0 = 'qV='
    var_0 = module_0.rabin_karp_find_substring(str_0, str_0)
    assert var_0 == 0

def test_case_1():
    str_0 = ',8+qd\n%1j'
    str_1 = 'q='
    var_0 = module_0.rabin_karp_find_substring(str_0, str_1)
    assert var_0 == -1
