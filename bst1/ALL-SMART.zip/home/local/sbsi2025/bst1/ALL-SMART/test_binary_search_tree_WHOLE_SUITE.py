#Pyguin test cases converted from bst1/WHOLE_SUITE/seed_1706/test_binary_search_tree.py
import pytest
import binary_search_tree as module_0
import tree_node as module_1

def test_case_0():
    binary_search_tree_0 = module_0.BinarySearchTree()
    none_type_0 = None
    var_0 = binary_search_tree_0.insert(none_type_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'
    bool_0 = True
    var_1 = binary_search_tree_0.search(none_type_0)
    assert f'{type(var_1).__module__}.{type(var_1).__qualname__}' == 'tree_node.BinaryTreeNode'
    assert var_1.left is None
    assert var_1.right is None
    assert var_1.value is None
    assert var_1.parent is None
    var_2 = binary_search_tree_0.in_order_traversal()

def test_case_1():
    binary_search_tree_0 = module_0.BinarySearchTree()
    binary_search_tree_1 = module_0.BinarySearchTree()
    binary_search_tree_2 = module_0.BinarySearchTree()

def test_case_2():
    none_type_0 = None
    binary_search_tree_0 = module_0.BinarySearchTree()
    binary_search_tree_1 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_1.in_order_traversal()

def test_case_3():
    dict_0 = {}
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.merge(binary_search_tree_0)
    var_1 = binary_search_tree_0.insert(dict_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'
    var_2 = binary_search_tree_0.min()

def test_case_4():
    binary_search_tree_0 = module_0.BinarySearchTree()
    binary_search_tree_1 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.insert(binary_search_tree_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'
    var_1 = binary_search_tree_0.merge(binary_search_tree_1)
    var_2 = binary_search_tree_0.in_order_traversal()

def test_case_5():
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.in_order_traversal()
    var_1 = binary_search_tree_0.in_order_traversal()
    bool_0 = True
    binary_search_tree_1 = module_0.BinarySearchTree()

def test_case_6():
    bytes_0 = b'\xe8\x02='
    bytes_1 = b'xk\xa53\xced\x80y\xa0\x8f\xd7f\xb8\xb2&m'
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.insert(bytes_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'
    var_1 = binary_search_tree_0.insert(bytes_0)
    var_2 = binary_search_tree_0.insert(bytes_1)

def test_case_7():
    bytes_0 = b'xk\xa53\xced\x80y\xa0\x8f\xd7f\xb8\xb2&m'
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.in_order_traversal()
    var_1 = binary_search_tree_0.insert(bytes_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'

def test_case_8():
    bytes_0 = b'\xe8\x02='
    bytes_1 = b'xk\xa53\xced\x80y\xa0\x8f\xd7f\xb8\xb2&m'
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.insert(bytes_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'
    var_1 = binary_search_tree_0.insert(bytes_0)
    var_2 = binary_search_tree_0.search(bytes_1)
    binary_search_tree_1 = module_0.BinarySearchTree()

def test_case_9():
    bytes_0 = b''
    bytes_1 = b'xk\xa53\xced\x80y\xa0\x8f\xd7f\xb8\xb2&m'
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.insert(bytes_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'
    var_1 = binary_search_tree_0.insert(bytes_0)
    var_2 = binary_search_tree_0.search(bytes_1)

def test_case_10():
    bytes_0 = b'\xe8='
    bytes_1 = b'xk\xa53\xced\x80y\xa0\x8f\xd7f\xb8\xb2&m'
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.insert(bytes_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'
    var_1 = binary_search_tree_0.insert(bytes_1)
    var_2 = binary_search_tree_0.insert(bytes_1)

def test_case_11():
    bytes_0 = b')\xd1\xec\x98y&#\xa8\x1e\xafY'
    bytes_1 = b'xk\xa53\xced\x80y\xa0\x8f\xd7f\xb8\xb2&m'
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.insert(bytes_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'
    var_1 = binary_search_tree_0.insert(bytes_0)
    var_2 = binary_search_tree_0.insert(bytes_1)

def test_case_12():
    binary_search_tree_0 = module_0.BinarySearchTree()

def test_case_13():
    binary_search_tree_0 = module_0.BinarySearchTree()
    binary_search_tree_1 = module_0.BinarySearchTree()
    binary_search_tree_2 = module_0.BinarySearchTree()

def test_case_14():
    binary_search_tree_0 = module_0.BinarySearchTree()
    binary_search_tree_1 = module_0.BinarySearchTree()
    binary_search_tree_2 = module_0.BinarySearchTree()
    binary_search_tree_3 = module_0.BinarySearchTree()

def test_case_15():
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.insert(binary_search_tree_0)
    assert f'{type(binary_search_tree_0.head).__module__}.{type(binary_search_tree_0.head).__qualname__}' == 'tree_node.BinaryTreeNode'

def test_case_16():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    binary_search_tree_0 = module_0.BinarySearchTree()
    var_0 = binary_search_tree_0.search(dict_0)

def test_case_17():
    none_type_0 = None
    str_0 = "\x0b!qs7';&?\rY~"
    binary_tree_node_0 = module_1.BinaryTreeNode(none_type_0, str_0)
    var_0 = binary_tree_node_0.min()
