#Pyguin test cases converted from convert-base/DYNAMOSA/seed_1706/test_convert_base.py
import pytest
import convert_base as module_0

def test_case_0():
    none_type_0 = None
    int_0 = 3048
    var_0 = module_0.convert_base(none_type_0, int_0)
    assert var_0 == -1
    var_1 = module_0.convert_base(var_0, var_0)
    assert var_1 == -1

def test_case_1():
    bool_0 = False

def test_case_2():
    str_0 = 'pc\x0b+P1'
    var_0 = module_0.convert_digit_to_int(str_0)
    assert var_0 == -1

def test_case_3():
    str_0 = "n>Tz*D\x0b'J=kK7"
    var_0 = module_0.convert_digit_to_int(str_0)
    assert var_0 == -1
    var_1 = module_0.convert_digit_to_int(str_0)
    assert var_1 == -1
    bool_0 = False
    var_2 = module_0.convert_base(str_0, bool_0)
    assert var_2 == -1

def test_case_4():
    str_0 = 'Fr`#/'
    int_0 = 1922
    var_0 = module_0.convert_base(str_0, int_0)
    assert var_0 == -1

def test_case_5():
    str_0 = 'G(7M'
    bool_0 = False

def test_case_6():
    str_0 = "n>Tz*D\x0b'J=kK7"
    var_0 = module_0.convert_digit_to_int(str_0)
    assert var_0 == -1
    var_1 = module_0.convert_digit_to_int(str_0)
    assert var_1 == -1
    bool_0 = False
    var_2 = module_0.convert_base(str_0, bool_0)
    assert var_2 == -1
    str_1 = 'D<X0]\r-'
    bool_1 = False
    var_3 = module_0.convert_base(str_1, bool_1)
    assert var_3 == -1

def test_case_7():
    str_0 = 'g\x0coz'
    bool_0 = True
    var_0 = module_0.convert_base(str_0, bool_0)
    assert var_0 == -1
    var_1 = module_0.convert_digit_to_int(str_0)
    assert var_1 == -1
    var_2 = module_0.convert_digit_to_int(str_0)
    assert var_2 == -1
    bool_1 = False
    str_1 = ''
    var_3 = module_0.convert_base(str_1, bool_1)
    assert var_3 == 0
    str_2 = '9m'
    var_4 = module_0.convert_digit_to_int(str_2)
    assert var_4 == -1

def test_case_8():
    str_0 = '0^'
    bool_0 = True

def test_case_9():
    str_0 = 'E\r?1\r/0EJ5'
    var_0 = module_0.convert_digit_to_int(str_0)
    assert var_0 == -1
    var_1 = module_0.convert_digit_to_int(str_0)
    assert var_1 == -1
    str_1 = 'B'
    var_2 = module_0.convert_base(str_1, var_1)
    assert var_2 == -1
    str_2 = 'q(v3.VfPv'
    int_0 = 16
    var_3 = module_0.convert_base(str_2, int_0)
    assert var_3 == -1
    bool_0 = True
