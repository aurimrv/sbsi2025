#Pyguin test cases converted from naive-tree/WHOLE_SUITE/seed_1706/test_naive_tree.py
import pytest
import naive_tree as module_0

def test_case_0():
    naive_binary_tree_0 = module_0.NaiveBinaryTree()

def test_case_1():
    naive_binary_tree_0 = module_0.NaiveBinaryTree()

def test_case_2():
    naive_binary_tree_0 = module_0.NaiveBinaryTree()

def test_case_3():
    naive_binary_tree_0 = module_0.NaiveBinaryTree()
    var_0 = naive_binary_tree_0.__str__()
    assert var_0 == '[]'
    naive_binary_tree_1 = module_0.NaiveBinaryTree()

def test_case_4():
    naive_binary_tree_0 = module_0.NaiveBinaryTree()
    var_0 = naive_binary_tree_0.post_order_traversal()
    naive_binary_tree_1 = module_0.NaiveBinaryTree()
    var_1 = naive_binary_tree_0.__str__()
    assert var_1 == '[]'
    var_2 = naive_binary_tree_0.in_order_traversal()
    naive_binary_tree_2 = module_0.NaiveBinaryTree()
    var_3 = naive_binary_tree_2.in_order_traversal()
    naive_binary_tree_3 = module_0.NaiveBinaryTree()

def test_case_5():
    naive_binary_tree_0 = module_0.NaiveBinaryTree()
    naive_binary_tree_1 = module_0.NaiveBinaryTree()
    var_0 = naive_binary_tree_1.post_order_traversal()
    var_1 = naive_binary_tree_1.pre_order_traversal()
    var_2 = naive_binary_tree_1.post_order_traversal()
    var_3 = naive_binary_tree_1.post_order_traversal()
    var_4 = var_2.__str__()
