#Pyguin test cases converted from perm-word/DYNAMOSA/seed_1706/test_permutations.py
import pytest
import permutations as module_0

def test_case_0():
    str_0 = 'Kh'
    var_0 = module_0.permutations_of_word(str_0)

def test_case_1():
    bool_0 = False
