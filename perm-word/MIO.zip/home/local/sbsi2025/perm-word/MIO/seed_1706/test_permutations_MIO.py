#Pyguin test cases converted from perm-word/MIO/seed_1706/test_permutations.py
import pytest
import permutations as module_0

def test_case_0():
    str_0 = 'zm5\\^o${'
    var_0 = module_0.permutations_of_word(str_0)
    none_type_0 = None

def test_case_1():
    none_type_0 = None
