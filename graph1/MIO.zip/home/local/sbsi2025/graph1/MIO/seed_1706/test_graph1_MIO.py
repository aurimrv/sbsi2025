#Pyguin test cases converted from graph1/MIO/seed_1706/test_graph1.py
import pytest
import graph1 as module_0

def test_case_0():
    int_0 = 3280
    graph_0 = module_0.Graph(int_0)
    var_0 = graph_0.add_edge(graph_0, int_0)
    assert len(graph_0.graph) == 2
    var_1 = graph_0.add_edge(graph_0, graph_0)

def test_case_1():
    int_0 = 588
    graph_0 = module_0.Graph(int_0)
    var_0 = graph_0.add_edge(int_0, int_0)
    assert graph_0.graph == {588: [588]}

def test_case_2():
    int_0 = 2695
    graph_0 = module_0.Graph(int_0)
    var_0 = graph_0.add_edge(graph_0, int_0)
    assert len(graph_0.graph) == 2

def test_case_3():
    int_0 = -3175
    graph_0 = module_0.Graph(int_0)
    with pytest.raises(IndexError):
        graph_0.add_edge(int_0, graph_0)

def test_case_4():
    int_0 = 804
    graph_0 = module_0.Graph(int_0)

def test_case_5():
    int_0 = -3972
    graph_0 = module_0.Graph(int_0)
    var_0 = graph_0.has_cycle()
    assert var_0 is False

def test_case_6():
    bool_0 = True
    graph_0 = module_0.Graph(bool_0)
    bool_1 = False
    var_0 = graph_0.add_edge(graph_0, bool_1)
    assert len(graph_0.graph) == 2
    var_1 = graph_0.has_cycle()
    assert var_1 is False

def test_case_7():
    bool_0 = True
    graph_0 = module_0.Graph(bool_0)
    bool_1 = False
    var_0 = graph_0.add_edge(bool_1, bool_1)
    assert graph_0.graph == {False: [False]}
    var_1 = graph_0.has_cycle()
    assert var_1 is True

def test_case_8():
    int_0 = 551
    graph_0 = module_0.Graph(int_0)
    bool_0 = False
    var_0 = graph_0.add_edge(bool_0, int_0)
    assert graph_0.graph == {False: [551], 551: []}

def test_case_9():
    int_0 = 1135
    graph_0 = module_0.Graph(int_0)
    var_0 = graph_0.add_edge(int_0, int_0)
    assert graph_0.graph == {1135: [1135]}
    var_1 = graph_0.topological_sort()

def test_case_10():
    int_0 = 380
    graph_0 = module_0.Graph(int_0)
    var_0 = graph_0.add_edge(graph_0, int_0)
    assert len(graph_0.graph) == 2
    var_1 = graph_0.topological_sort()

def test_case_11():
    int_0 = 804
    graph_0 = module_0.Graph(int_0)
    var_0 = graph_0.topological_sort()

def test_case_12():
    weighted_graph_0 = module_0.WeightedGraph()
    none_type_0 = None
    var_0 = weighted_graph_0.add_edge(none_type_0, none_type_0)
    var_1 = weighted_graph_0.__str__()
    assert var_1 == 'None adjacent: [None]'

def test_case_13():
    int_0 = 532
    weighted_graph_node_0 = module_0.WeightedGraphNode(int_0)
    var_0 = weighted_graph_node_0.__str__()
    assert var_0 == '532 adjacent: []'

def test_case_14():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_edge(weighted_graph_0, weighted_graph_0)

def test_case_15():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.__str__()

def test_case_16():
    none_type_0 = None
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_edge(none_type_0, weighted_graph_0)
    assert len(weighted_graph_0.vertices) == 2

def test_case_17():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_edge(weighted_graph_0, weighted_graph_0)

def test_case_18():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_vertex(weighted_graph_0)
    var_1 = weighted_graph_0.add_edge(weighted_graph_0, var_0)
    assert len(weighted_graph_0.vertices) == 2

def test_case_19():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_vertex(weighted_graph_0)
    var_1 = weighted_graph_0.remove_edge(weighted_graph_0, var_0)
    graph_0 = module_0.Graph(weighted_graph_0)

def test_case_20():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_vertex(weighted_graph_0)
    var_1 = weighted_graph_0.remove_edge(weighted_graph_0, weighted_graph_0)

def test_case_21():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_edge(weighted_graph_0, weighted_graph_0)
    var_1 = weighted_graph_0.remove_edge(weighted_graph_0, weighted_graph_0)

def test_case_22():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.remove_edge(weighted_graph_0, weighted_graph_0)

def test_case_23():
    weighted_graph_0 = module_0.WeightedGraph()

def test_case_24():
    int_0 = 92
    graph_node_0 = module_0.GraphNode(int_0)

def test_case_25():
    int_0 = 5852
    graph_node_0 = module_0.GraphNode(int_0)
    var_0 = graph_node_0.add_adjacent(graph_node_0)

def test_case_26():
    int_0 = -1899
    graph_node_0 = module_0.GraphNode(int_0)

def test_case_27():
    int_0 = 779
    graph_0 = module_0.Graph(int_0)

def test_case_28():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_vertex(weighted_graph_0)

def test_case_29():
    int_0 = 1964
    weighted_graph_node_0 = module_0.WeightedGraphNode(int_0)
