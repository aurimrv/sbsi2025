#Pyguin test cases converted from graph1/WHOLE_SUITE/seed_1706/test_graph1.py
import pytest
import graph1 as module_0

def test_case_0():
    none_type_0 = None
    bool_0 = False
    weighted_graph_node_0 = module_0.WeightedGraphNode(bool_0)

def test_case_1():
    bool_0 = False
    weighted_graph_0 = module_0.WeightedGraph()
    graph_0 = module_0.Graph(bool_0)
    var_0 = graph_0.has_cycle()
    assert var_0 is False

def test_case_2():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_vertex(weighted_graph_0)
    weighted_graph_1 = module_0.WeightedGraph()
    var_1 = weighted_graph_0.remove_edge(weighted_graph_0, weighted_graph_0)
    graph_node_0 = module_0.GraphNode(var_1)
    var_2 = weighted_graph_1.add_vertex(var_1)
    var_3 = var_1.__str__()
    var_4 = var_0.__str__()
    none_type_0 = None
    var_5 = weighted_graph_1.add_edge(var_1, none_type_0)
    var_6 = weighted_graph_1.__str__()
    assert var_6 == 'None adjacent: [None]'
    var_7 = weighted_graph_0.add_vertex(var_1)
    var_8 = weighted_graph_0.remove_edge(none_type_0, none_type_0)

def test_case_3():
    int_0 = 282
    graph_0 = module_0.Graph(int_0)
    bool_0 = True
    graph_node_0 = module_0.GraphNode(bool_0)

def test_case_4():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_edge(weighted_graph_0, weighted_graph_0)
    var_1 = weighted_graph_0.remove_edge(weighted_graph_0, var_0)

def test_case_5():
    none_type_0 = None
    graph_node_0 = module_0.GraphNode(none_type_0)
    weighted_graph_0 = module_0.WeightedGraph()
    weighted_graph_1 = module_0.WeightedGraph()
    var_0 = graph_node_0.add_adjacent(weighted_graph_1)
    var_1 = weighted_graph_1.__str__()
    var_2 = weighted_graph_0.add_edge(weighted_graph_1, var_1)
    assert len(weighted_graph_0.vertices) == 2

def test_case_6():
    int_0 = 1740
    graph_0 = module_0.Graph(int_0)
    var_0 = graph_0.add_edge(int_0, graph_0)
    assert len(graph_0.graph) == 2
    graph_node_0 = module_0.GraphNode(var_0)
    var_1 = graph_0.topological_sort()

def test_case_7():
    bool_0 = False
    graph_0 = module_0.Graph(bool_0)
    graph_1 = module_0.Graph(bool_0)
    var_0 = graph_1.topological_sort()
    weighted_graph_0 = module_0.WeightedGraph()
    var_1 = graph_1.topological_sort()
    var_2 = graph_0.add_edge(bool_0, bool_0)
    assert graph_0.graph == {False: [False]}
    var_3 = var_1.__str__()
    var_4 = graph_0.topological_sort()

def test_case_8():
    bool_0 = True
    graph_0 = module_0.Graph(bool_0)
    var_0 = graph_0.add_edge(bool_0, bool_0)
    assert graph_0.graph == {True: [True]}
    var_1 = graph_0.add_edge(bool_0, var_0)
    assert graph_0.graph == {True: [True, None], None: []}
    var_2 = var_0.__str__()
    graph_1 = module_0.Graph(bool_0)

def test_case_9():
    bool_0 = True
    graph_0 = module_0.Graph(bool_0)
    var_0 = graph_0.add_edge(bool_0, bool_0)
    assert graph_0.graph == {True: [True]}
    var_1 = graph_0.add_edge(bool_0, var_0)
    assert graph_0.graph == {True: [True, None], None: []}
    var_2 = var_0.__str__()
    graph_1 = module_0.Graph(bool_0)

def test_case_10():
    weighted_graph_0 = module_0.WeightedGraph()
    none_type_0 = None
    var_0 = weighted_graph_0.add_edge(weighted_graph_0, weighted_graph_0)
    var_1 = weighted_graph_0.add_edge(none_type_0, weighted_graph_0, none_type_0)
    assert len(weighted_graph_0.vertices) == 2
    var_2 = weighted_graph_0.remove_edge(none_type_0, weighted_graph_0)

def test_case_11():
    none_type_0 = None
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.add_vertex(none_type_0)

def test_case_12():
    bytes_0 = b'\x84z\xb8\xcc&\xb7O\x19\xc4\xd0\x10\x98t'
    bool_0 = False
    dict_0 = {bytes_0: bool_0, bool_0: bytes_0}
    weighted_graph_0 = module_0.WeightedGraph()
    graph_0 = module_0.Graph(weighted_graph_0)

def test_case_13():
    int_0 = -3190
    graph_0 = module_0.Graph(int_0)
    weighted_graph_0 = module_0.WeightedGraph()
    none_type_0 = None
    var_0 = weighted_graph_0.remove_edge(none_type_0, weighted_graph_0)
    with pytest.raises(IndexError):
        graph_0.add_edge(int_0, weighted_graph_0)

def test_case_14():
    weighted_graph_0 = module_0.WeightedGraph()
    var_0 = weighted_graph_0.remove_edge(weighted_graph_0, weighted_graph_0)
    var_1 = var_0.__str__()
    var_2 = var_1.__str__()
