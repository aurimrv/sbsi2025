import os
import sys
import pytest

module_dir = os.path.dirname(os.path.abspath(__file__))
project_dir = os.path.abspath(os.path.join(module_dir, '..'))
sys.path.append(project_dir)

from graph1 import GraphNode, Graph, WeightedGraphNode, WeightedGraph

@pytest.fixture
def setup_graph():
    graph = Graph(5)
    graph.add_edge(0, 1)
    graph.add_edge(1, 2)
    graph.add_edge(2, 3)
    graph.add_edge(3, 4)
    return graph

def test_graph_node_add_adjacent():
    node1 = GraphNode(1)
    node2 = GraphNode(2)
    node1.add_adjacent(node2)
    assert len(node1.adjacent_list) == 1
    assert node2 in node1.adjacent_list

def test_graph_node_remove_adjacent():
    node1 = GraphNode(1)
    node2 = GraphNode(2)
    node1.add_adjacent(node2)
    node1.remove_adjacent(node2)
    assert len(node1.adjacent_list) == 0

def test_graph_add_edge(setup_graph):
    assert setup_graph.graph == {0: [1], 1: [2], 2: [3], 3: [4], 4: []}

def test_graph_has_cycle(setup_graph):
    assert not setup_graph.has_cycle()

def test_weighted_graph_node_add_adjacent():
    node1 = WeightedGraphNode(1)
    node2 = WeightedGraphNode(2)
    node1.add_adjacent(node2, 5)
    assert node2 in node1.adjacent and node1.adjacent[node2] == 5

def test_weighted_graph_node_remove_adjacent():
    node1 = WeightedGraphNode(1)
    node2 = WeightedGraphNode(2)
    node1.add_adjacent(node2, 5)
    node1.remove_adjacent(node2)
    assert node2 not in node1.adjacent

def test_weighted_graph_add_edge():
    weighted_graph = WeightedGraph()
    weighted_graph.add_edge(1, 2, 3)
    weighted_graph.add_edge(1, 3, 2)
    assert weighted_graph.vertices[1].adjacent == {2: 3, 3: 2}

def test_weighted_graph_remove_edge():
    weighted_graph = WeightedGraph()
    weighted_graph.add_edge(1, 2, 3)
    weighted_graph.add_edge(1, 3, 2)
    weighted_graph.remove_edge(1, 3)
    assert 3 not in weighted_graph.vertices[1].adjacent