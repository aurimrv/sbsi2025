#Pyguin test cases converted from complement/WHOLE_SUITE/seed_1706/test_complement.py
import pytest
import complement as module_0
import builtins as module_1

def test_case_0():
    int_0 = 1415
    var_0 = module_0.complement(int_0)
    assert var_0 == 632
    var_1 = module_0.complement(int_0)
    assert var_1 == 632
    none_type_0 = None
    var_2 = module_0.complement(var_0)
    assert var_2 == 391
    var_3 = module_0.complement(none_type_0)
    assert var_3 == 1
    var_4 = module_0.complement(var_3)
    assert var_4 == 0
    var_5 = module_0.complement(none_type_0)
    assert var_5 == 1
    var_6 = module_0.complement(var_3)
    assert var_6 == 0
    var_7 = module_0.complement(var_3)
    assert var_7 == 0
    var_8 = module_0.complement(var_3)
    assert var_8 == 0
    var_9 = module_0.complement(none_type_0)
    assert var_9 == 1
    var_10 = module_0.complement(none_type_0)
    assert var_10 == 1
    list_0 = [var_10, var_10]
    var_11 = module_0.complement(var_10)
    assert var_11 == 0
    var_12 = module_0.complement(var_10)
    assert var_12 == 0
    var_13 = module_0.complement(var_12)
    assert var_13 == 1
    var_14 = module_0.complement(var_12)
    assert var_14 == 1
    float_0 = -407.75
    var_15 = module_0.complement(var_8)
    assert var_15 == 1
    var_16 = module_0.complement(float_0)
    assert var_16 == pytest.approx(-407.75, abs=0.01, rel=0.01)
    var_17 = module_0.complement(var_12)
    assert var_17 == 1

def test_case_1():
    bytes_0 = b'`\x0c\xb5\x99\xd284\x1c\xf9\x1aR\xd7\x18\xed.+\x88\xad\xd9\xe4'

def test_case_2():
    int_0 = -1425
    var_0 = module_0.complement(int_0)
    assert var_0 == -1425
    var_1 = module_0.complement(int_0)
    assert var_1 == -1425
    var_2 = module_0.complement(var_1)
    assert var_2 == -1425
    str_0 = 'A'

def test_case_3():
    object_0 = module_1.object()

def test_case_4():
    bytes_0 = b'\xee{{\xd8\x8e\r\x9c\xca'
    list_0 = [bytes_0, bytes_0]

def test_case_5():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}

def test_case_6():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}

def test_case_7():
    float_0 = -668.911821
    var_0 = module_0.complement(float_0)
    assert var_0 == pytest.approx(-668.911821, abs=0.01, rel=0.01)

def test_case_8():
    str_0 = 'mCj(m&rYtS2}m*#26mz1'
