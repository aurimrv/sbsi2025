#Pyguin test cases converted from linked-list2/MIO/seed_1706/test_linked_list2.py
import pytest
import linked_list2 as module_0

def test_case_0():
    str_0 = 'r*YH=DKUi$Ex|'
    linked_list_0 = module_0.LinkedList(str_0)
    assert f'{type(linked_list_0.head).__module__}.{type(linked_list_0.head).__qualname__}' == 'linked_list2.Node'

def test_case_1():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    linked_list_1 = module_0.LinkedList(linked_list_0)
    assert f'{type(linked_list_1.head).__module__}.{type(linked_list_1.head).__qualname__}' == 'linked_list2.Node'

def test_case_2():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None

def test_case_3():
    bool_0 = True
    linked_list_0 = module_0.LinkedList(bool_0)
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert f'{type(linked_list_0.head).__module__}.{type(linked_list_0.head).__qualname__}' == 'linked_list2.Node'
    var_0 = linked_list_0.pop()
    assert var_0 is True
    assert linked_list_0.head is None

def test_case_4():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    with pytest.raises(IndexError):
        linked_list_0.pop()

def test_case_5():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.push(linked_list_0)
    var_1 = linked_list_0.search(linked_list_0)
    assert f'{type(var_1).__module__}.{type(var_1).__qualname__}' == 'linked_list2.Node'
    assert f'{type(var_1.data).__module__}.{type(var_1.data).__qualname__}' == 'linked_list2.LinkedList'
    assert var_1.next is None

def test_case_6():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.push(linked_list_0)
    var_1 = linked_list_0.search(var_0)

def test_case_7():
    str_0 = '%d0laE'
    linked_list_0 = module_0.LinkedList(str_0)
    assert f'{type(linked_list_0.head).__module__}.{type(linked_list_0.head).__qualname__}' == 'linked_list2.Node'
    var_0 = linked_list_0.search(linked_list_0)

def test_case_8():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.search(linked_list_0)

def test_case_9():
    bytes_0 = b'\xef6\x16\xe0\xc2\xeb\xb0\xac\x80\xe4\xfd55\xaeK\xcd\xe3'
    linked_list_0 = module_0.LinkedList(bytes_0)
    assert f'{type(linked_list_0.head).__module__}.{type(linked_list_0.head).__qualname__}' == 'linked_list2.Node'
    var_0 = linked_list_0.remove(bytes_0)

def test_case_10():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.push(linked_list_0)
    var_1 = linked_list_0.remove(linked_list_0)
    assert linked_list_0.head is None

def test_case_11():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.push(linked_list_0)
    var_1 = linked_list_0.remove(var_0)

def test_case_12():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.remove(linked_list_0)

def test_case_13():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.push(linked_list_0)
    var_1 = linked_list_0.push(linked_list_0)
    var_2 = linked_list_0.remove(linked_list_0)

def test_case_14():
    bytes_0 = b'\xef6\x16\xe0\xc2\xeb\xb0\xac\x80\xe4\xfd55\xaeK\xcd\xe3'
    linked_list_0 = module_0.LinkedList(bytes_0)
    assert f'{type(linked_list_0.head).__module__}.{type(linked_list_0.head).__qualname__}' == 'linked_list2.Node'
    var_0 = linked_list_0.display()
    assert var_0 == '(227, 205, 75, 174, 53, 53, 253, 228, 128, 172, 176, 235, 194, 224, 22, 54, 239)'

def test_case_15():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.push(linked_list_0)
    var_1 = linked_list_0.display()

def test_case_16():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.display()
    assert var_0 == ')'

def test_case_17():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    node_0 = module_0.Node(linked_list_0)

def test_case_18():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.size()
    assert var_0 == 0
