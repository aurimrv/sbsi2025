#Pyguin test cases converted from linked-list2/DYNAMOSA/seed_1706/test_linked_list2.py
import pytest
import linked_list2 as module_0

def test_case_0():
    bool_0 = True
    list_0 = [bool_0, bool_0]
    linked_list_0 = module_0.LinkedList(list_0)
    assert f'{type(linked_list_0.head).__module__}.{type(linked_list_0.head).__qualname__}' == 'linked_list2.Node'
    none_type_0 = None
    var_0 = linked_list_0.search(none_type_0)

def test_case_1():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None

def test_case_2():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    with pytest.raises(IndexError):
        linked_list_0.pop()

def test_case_3():
    int_0 = 1000
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.search(int_0)

def test_case_4():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.remove(linked_list_0)
    var_1 = linked_list_0.push(var_0)
    var_2 = linked_list_0.push(linked_list_0)
    bool_0 = True
    var_3 = linked_list_0.remove(linked_list_0)
    node_0 = module_0.Node(bool_0)
    var_4 = linked_list_0.push(var_3)

def test_case_5():
    bytes_0 = b'\xbe'
    linked_list_0 = module_0.LinkedList(bytes_0)
    assert f'{type(linked_list_0.head).__module__}.{type(linked_list_0.head).__qualname__}' == 'linked_list2.Node'
    var_0 = linked_list_0.search(linked_list_0)
    var_1 = linked_list_0.display()
    assert var_1 == '(190)'
    var_2 = linked_list_0.push(linked_list_0)
    var_3 = linked_list_0.remove(bytes_0)

def test_case_6():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.display()
    assert var_0 == ')'
    with pytest.raises(IndexError):
        linked_list_0.pop()

def test_case_7():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    linked_list_1 = module_0.LinkedList()
    assert linked_list_1.head is None
    linked_list_2 = module_0.LinkedList()
    assert linked_list_2.head is None
    var_0 = linked_list_2.size()
    assert var_0 == 0

def test_case_8():
    none_type_0 = None
    none_type_1 = None
    linked_list_0 = module_0.LinkedList(none_type_1)
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.search(none_type_0)
    set_0 = set()
    bool_0 = False
    node_0 = module_0.Node(bool_0)
    linked_list_1 = module_0.LinkedList(node_0)
    assert f'{type(linked_list_1.head).__module__}.{type(linked_list_1.head).__qualname__}' == 'linked_list2.Node'
    var_1 = linked_list_1.push(set_0)

def test_case_9():
    linked_list_0 = module_0.LinkedList()
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.remove(linked_list_0)
    var_1 = linked_list_0.push(var_0)
    var_2 = linked_list_0.push(linked_list_0)
    var_3 = linked_list_0.remove(var_0)
    none_type_0 = None
    var_4 = linked_list_0.remove(none_type_0)

def test_case_10():
    bytes_0 = b'\xbe'
    linked_list_0 = module_0.LinkedList(bytes_0)
    assert f'{type(linked_list_0.head).__module__}.{type(linked_list_0.head).__qualname__}' == 'linked_list2.Node'
    var_0 = linked_list_0.remove(linked_list_0)
    var_1 = linked_list_0.display()
    assert var_1 == '(190)'
    var_2 = linked_list_0.push(linked_list_0)
    var_3 = module_0.LinkedList()
    assert f'{type(var_3).__module__}.{type(var_3).__qualname__}' == 'linked_list2.LinkedList'
    assert var_3.head is None
    var_4 = linked_list_0.display()
    var_5 = linked_list_0.remove(var_4)

def test_case_11():
    bool_0 = True
    linked_list_0 = module_0.LinkedList(bool_0)
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert f'{type(linked_list_0.head).__module__}.{type(linked_list_0.head).__qualname__}' == 'linked_list2.Node'
    var_0 = linked_list_0.search(bool_0)
    assert f'{type(var_0).__module__}.{type(var_0).__qualname__}' == 'linked_list2.Node'
    assert var_0.data is True
    assert var_0.next is None

def test_case_12():
    bool_0 = True
    none_type_0 = None
    linked_list_0 = module_0.LinkedList(none_type_0)
    assert f'{type(linked_list_0).__module__}.{type(linked_list_0).__qualname__}' == 'linked_list2.LinkedList'
    assert linked_list_0.head is None
    var_0 = linked_list_0.size()
    assert var_0 == 0
    var_1 = linked_list_0.push(linked_list_0)
    var_2 = linked_list_0.remove(var_0)
    linked_list_1 = module_0.LinkedList()
    assert linked_list_1.head is None
    linked_list_2 = module_0.LinkedList()
    assert linked_list_2.head is None
    var_3 = linked_list_0.pop()
    assert linked_list_0.head is None
    assert f'{type(var_3).__module__}.{type(var_3).__qualname__}' == 'linked_list2.LinkedList'
    assert var_3.head is None
    var_4 = var_3.push(bool_0)
    with pytest.raises(IndexError):
        linked_list_1.pop()
