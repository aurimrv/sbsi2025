#Pyguin test cases converted from bfs/WHOLE_SUITE/seed_1706/test_breadth_first_search.py
import pytest
import breadth_first_search as module_0

def test_case_0():
    bool_0 = False
    list_0 = [bool_0, bool_0]
    str_0 = '*\r'
    var_0 = module_0.breadth_first_search(str_0, list_0, str_0)
    var_1 = module_0.breadth_first_search(str_0, list_0, var_0)

def test_case_1():
    dict_0 = {}
    dict_1 = {}

def test_case_2():
    none_type_0 = None

def test_case_3():
    dict_0 = {}
    var_0 = module_0.breadth_first_search(dict_0, dict_0, dict_0)

def test_case_4():
    bool_0 = False

def test_case_5():
    none_type_0 = None

def test_case_6():
    bool_0 = True
    bytes_0 = b'\x82O\x90\xd5p\x1a\xb3\xf5\xe0iR\x9f\x96\xa6\xb8uTh'

def test_case_7():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    list_1 = [list_0, bool_0, bool_0, bool_0]
    var_0 = module_0.breadth_first_search(list_1, list_0, bool_0)
