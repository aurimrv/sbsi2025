#Pyguin test cases converted from bfs/MIO/seed_1706/test_breadth_first_search.py
import pytest
import breadth_first_search as module_0
import builtins as module_1

def test_case_0():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    list_1 = [list_0, list_0, list_0, bool_0, list_0, bool_0, list_0]
    none_type_0 = None

def test_case_1():
    str_0 = 'B1.ox}hZ2`'

def test_case_2():
    str_0 = ''
    var_0 = module_0.breadth_first_search(str_0, str_0, str_0)

def test_case_3():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    list_1 = [list_0, list_0]
    none_type_0 = None
    var_0 = module_0.breadth_first_search(list_1, list_0, none_type_0)

def test_case_4():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0]
    list_1 = [list_0, list_0, bool_0, list_0]
    none_type_0 = None
    var_0 = module_0.breadth_first_search(list_1, list_0, bool_0)

def test_case_5():
    object_0 = module_1.object()

def test_case_6():
    object_0 = module_1.object()
