#Pyguin test cases converted from queue/MIO/seed_1706/test_a_queue.py
import pytest
import a_queue as module_0

def test_case_0():
    queue_0 = module_0.Queue()
    var_0 = queue_0.peek()

def test_case_1():
    queue_0 = module_0.Queue()

def test_case_2():
    queue_0 = module_0.Queue()
    var_0 = queue_0.enqueue(queue_0)

def test_case_3():
    queue_0 = module_0.Queue()

def test_case_4():
    queue_0 = module_0.Queue()
    var_0 = queue_0.size()
