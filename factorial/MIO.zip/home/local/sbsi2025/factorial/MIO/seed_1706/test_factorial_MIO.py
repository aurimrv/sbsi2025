#Pyguin test cases converted from factorial/MIO/seed_1706/test_factorial.py
import pytest
import factorial as module_0

def test_case_0():
    bool_0 = False
    var_0 = module_0.factorial(bool_0)
    assert var_0 == 0

def test_case_1():
    bool_0 = True
    var_0 = module_0.factorial(bool_0)
    assert var_0 == 1
    str_0 = 'QI\n=;$$m(f6'

def test_case_2():
    bool_0 = False
    var_0 = module_0.factorial(bool_0)
    assert var_0 == 0
    var_1 = module_0.factorial(bool_0)
    assert var_1 == 0
    var_2 = module_0.factorial(var_0)
    assert var_2 == 0
    var_3 = module_0.factorial(var_0)
    assert var_3 == 0
    int_0 = -1546
    var_4 = module_0.factorial(var_1)
    assert var_4 == 0
    var_5 = module_0.factorial(int_0)
    assert var_5 == 0
    int_1 = 3636
    var_6 = module_0.factorial(bool_0)
    assert var_6 == 0
    var_7 = module_0.factorial(int_1)
    var_8 = module_0.factorial(int_0)
    assert var_8 == 0
    var_9 = module_0.factorial(var_8)
    assert var_9 == 0
    var_10 = module_0.factorial(var_0)
    assert var_10 == 0
    var_11 = module_0.factorial(var_1)
    assert var_11 == 0
    var_12 = module_0.factorial(int_0)
    assert var_12 == 0
