#Pyguin test cases converted from quicksort/WHOLE_SUITE/seed_1706/test_quicksort.py
import pytest
import quicksort as module_0

def test_case_0():
    bool_0 = False

def test_case_1():
    int_0 = 2954
    list_0 = [int_0, int_0]
    var_0 = module_0.quicksort(list_0)
    list_1 = [list_0, var_0]
    var_1 = module_0.quicksort(list_1)
    list_2 = []
    var_2 = module_0.quicksort(list_2)
    var_3 = module_0.quicksort(var_0)
    bool_0 = False

def test_case_2():
    bool_0 = False
    float_0 = -4081.35
    tuple_0 = (bool_0, bool_0, bool_0, float_0)

def test_case_3():
    bytes_0 = b'\xf4\x19\xd1T;\nt\xde2\xeav'
    list_0 = [bytes_0, bytes_0]
    var_0 = module_0.quicksort(list_0)

def test_case_4():
    int_0 = -770
    set_0 = {int_0, int_0, int_0, int_0}
    var_0 = module_0.quicksort(set_0)
    none_type_0 = None

def test_case_5():
    bool_0 = True
    list_0 = [bool_0]
    var_0 = module_0.quicksort(list_0)

def test_case_6():
    bool_0 = True
    list_0 = [bool_0, bool_0]
    var_0 = module_0.quicksort(list_0)
    none_type_0 = None

def test_case_7():
    str_0 = '[gdY&(Ks9\x0c0;'

def test_case_8():
    list_0 = []
    var_0 = module_0.quicksort(list_0)
    int_0 = -3435
    dict_0 = {int_0: int_0}
    var_1 = module_0.quicksort(dict_0)

def test_case_9():
    int_0 = 344
