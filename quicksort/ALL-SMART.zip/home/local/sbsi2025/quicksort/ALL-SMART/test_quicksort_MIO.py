#Pyguin test cases converted from quicksort/MIO/seed_1706/test_quicksort.py
import pytest
import quicksort as module_0
import builtins as module_1

def test_case_0():
    str_0 = "n>Tz*D\x0b'J=kK7"

def test_case_1():
    tuple_0 = ()
    var_0 = module_0.quicksort(tuple_0)
    var_1 = module_0.quicksort(var_0)
    var_2 = module_0.quicksort(var_1)
    var_3 = module_0.quicksort(var_0)
    var_4 = module_0.quicksort(var_3)
    var_5 = module_0.quicksort(var_0)
    var_6 = module_0.quicksort(var_0)
    var_7 = module_0.quicksort(var_0)
    var_8 = module_0.quicksort(var_3)

def test_case_2():
    tuple_0 = ()
    var_0 = module_0.quicksort(tuple_0)
    var_1 = module_0.quicksort(var_0)
    var_2 = module_0.quicksort(var_1)
    var_3 = module_0.quicksort(var_0)
    var_4 = module_0.quicksort(var_3)
    var_5 = module_0.quicksort(var_0)
    var_6 = module_0.quicksort(var_0)
    list_0 = [var_0]
    var_7 = module_0.quicksort(var_0)
    var_8 = module_0.quicksort(var_3)
    var_9 = module_0.quicksort(var_0)
    var_10 = module_0.quicksort(var_5)
    var_11 = module_0.quicksort(tuple_0)
    var_12 = module_0.quicksort(tuple_0)
    var_13 = module_0.quicksort(var_0)
    var_14 = module_0.quicksort(list_0)
    var_15 = module_0.quicksort(var_0)
    var_16 = module_0.quicksort(var_15)
    var_17 = module_0.quicksort(var_16)
    var_18 = module_0.quicksort(var_6)
    list_1 = [tuple_0, tuple_0]
    var_19 = module_0.quicksort(var_14)
    var_20 = module_0.quicksort(var_14)
    var_21 = module_0.quicksort(var_19)
    var_22 = module_0.quicksort(list_1)
