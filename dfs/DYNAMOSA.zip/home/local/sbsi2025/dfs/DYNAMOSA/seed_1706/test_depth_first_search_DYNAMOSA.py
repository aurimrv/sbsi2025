#Pyguin test cases converted from dfs/DYNAMOSA/seed_1706/test_depth_first_search.py
import pytest
import depth_first_search as module_0

def test_case_0():
    str_0 = 'aqELL5X>'

def test_case_1():
    list_0 = []
    var_0 = module_0.depth_first_search(list_0, list_0, list_0)
    str_0 = 'aqELL5X>'

def test_case_2():
    int_0 = 2627

def test_case_3():
    str_0 = 'ln4Ps&V!`]'
    bool_0 = False
    tuple_0 = (bool_0, bool_0, str_0)
    var_0 = module_0.depth_first_search(str_0, tuple_0, str_0)

def test_case_4():
    list_0 = []
    str_0 = 'l'
    bool_0 = False
    tuple_0 = (bool_0, bool_0, str_0)
    var_0 = module_0.depth_first_search(str_0, tuple_0, str_0)
    int_0 = -957

def test_case_5():
    list_0 = []
    var_0 = module_0.depth_first_search(list_0, list_0, list_0)
    var_1 = module_0.depth_first_search(list_0, var_0, list_0)
    var_2 = module_0.depth_first_search(list_0, var_0, list_0)
    bool_0 = False
    bool_1 = False
    tuple_0 = (bool_0, bool_1, var_0)
    dict_0 = {bool_0: tuple_0}
    var_3 = module_0.depth_first_search(dict_0, tuple_0, var_0)
