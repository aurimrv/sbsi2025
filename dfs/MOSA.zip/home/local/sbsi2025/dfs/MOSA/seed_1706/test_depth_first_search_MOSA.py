#Pyguin test cases converted from dfs/MOSA/seed_1706/test_depth_first_search.py
import pytest
import depth_first_search as module_0

def test_case_0():
    str_0 = 'aqELL5X>'

def test_case_1():
    tuple_0 = ()
    var_0 = module_0.depth_first_search(tuple_0, tuple_0, tuple_0)
    str_0 = 'B@"wJ'

def test_case_2():
    int_0 = 2627

def test_case_3():
    bool_0 = False
    tuple_0 = (bool_0, bool_0, bool_0)
    tuple_1 = (tuple_0, bool_0)

def test_case_4():
    bool_0 = False
    tuple_0 = (bool_0, bool_0, bool_0)
    tuple_1 = (tuple_0, bool_0)
    var_0 = module_0.depth_first_search(tuple_1, tuple_0, bool_0)

def test_case_5():
    bool_0 = False
    tuple_0 = (bool_0, bool_0, bool_0)
    tuple_1 = ()
    str_0 = 'I'
    var_0 = module_0.depth_first_search(str_0, tuple_0, tuple_1)
    var_1 = module_0.depth_first_search(tuple_1, tuple_1, tuple_1)

def test_case_6():
    bool_0 = False
    tuple_0 = (bool_0, bool_0, bool_0)
    tuple_1 = (tuple_0, bool_0)
    var_0 = module_0.depth_first_search(tuple_1, tuple_0, bool_0)
    str_0 = 'nKtKU\x0c(K_'
    var_1 = module_0.depth_first_search(str_0, tuple_0, tuple_1)

def test_case_7():
    bool_0 = False
    tuple_0 = (bool_0, bool_0, bool_0)
    tuple_1 = (tuple_0, bool_0)
    list_0 = [tuple_1, tuple_0]
    var_0 = module_0.depth_first_search(list_0, tuple_0, bool_0)
    var_1 = module_0.depth_first_search(tuple_1, tuple_0, bool_0)
