#Pyguin test cases converted from dfs/WHOLE_SUITE/seed_1706/test_depth_first_search.py
import pytest
import depth_first_search as module_0
import builtins as module_1

def test_case_0():
    bool_0 = True
    none_type_0 = None
    int_0 = -2106
    set_0 = {int_0, int_0, bool_0, int_0}
    bool_1 = True

def test_case_1():
    str_0 = 'T'
    bool_0 = False
    bool_1 = False
    tuple_0 = (bool_0, bool_0, bool_1, bool_1)
    var_0 = module_0.depth_first_search(str_0, tuple_0, tuple_0)
    var_1 = module_0.depth_first_search(str_0, tuple_0, str_0)
    list_0 = []
    bool_2 = True
    var_2 = module_0.depth_first_search(list_0, bool_2, var_1)
    var_3 = module_0.depth_first_search(list_0, list_0, str_0)

def test_case_2():
    str_0 = '<F'
    bool_0 = False
    complex_0 = -1571.7621 - 272.26252j
    bool_1 = True
    tuple_0 = (bool_0, bool_0, complex_0, bool_1)
    var_0 = module_0.depth_first_search(str_0, tuple_0, tuple_0)
    var_1 = module_0.depth_first_search(str_0, tuple_0, str_0)
    list_0 = []
    bool_2 = True
    var_2 = module_0.depth_first_search(list_0, bool_2, var_1)
    var_3 = module_0.depth_first_search(list_0, list_0, str_0)

def test_case_3():
    none_type_0 = None

def test_case_4():
    list_0 = []
    var_0 = module_0.depth_first_search(list_0, list_0, list_0)
    tuple_0 = (var_0, var_0, list_0)

def test_case_5():
    bytes_0 = b'/\xa0'

def test_case_6():
    int_0 = 2143
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0, int_0: int_0}
    tuple_0 = (int_0, dict_0)
    tuple_1 = (tuple_0,)
    tuple_2 = (tuple_1, int_0)
    none_type_0 = None

def test_case_7():
    none_type_0 = None

def test_case_8():
    none_type_0 = None

def test_case_9():
    none_type_0 = None

def test_case_10():
    none_type_0 = None
