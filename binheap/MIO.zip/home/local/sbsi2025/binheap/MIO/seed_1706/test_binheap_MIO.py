#Pyguin test cases converted from binheap/MIO/seed_1706/test_binheap.py
import pytest
import binheap as module_0

def test_case_0():
    str_0 = 'r'
    binheap_0 = module_0.Binheap(str_0)
    assert f'{type(binheap_0).__module__}.{type(binheap_0).__qualname__}' == 'binheap.Binheap'
    assert binheap_0.container == [None, 'r']

def test_case_1():
    binheap_0 = module_0.Binheap()
    assert f'{type(binheap_0).__module__}.{type(binheap_0).__qualname__}' == 'binheap.Binheap'
    assert binheap_0.container == [None]
    var_0 = binheap_0.display()
    assert var_0 == ''

def test_case_2():
    binheap_0 = module_0.Binheap()
    assert f'{type(binheap_0).__module__}.{type(binheap_0).__qualname__}' == 'binheap.Binheap'
    assert binheap_0.container == [None]

def test_case_3():
    bytes_0 = b'g\x92\xbf\xe8\xeat%'
    binheap_0 = module_0.Binheap(bytes_0)
    assert f'{type(binheap_0).__module__}.{type(binheap_0).__qualname__}' == 'binheap.Binheap'
    assert binheap_0.container == [None, 234, 232, 146, 103, 191, 116, 37]

def test_case_4():
    binheap_0 = module_0.Binheap()
    assert f'{type(binheap_0).__module__}.{type(binheap_0).__qualname__}' == 'binheap.Binheap'
    assert binheap_0.container == [None]
    var_0 = binheap_0.push(binheap_0)

def test_case_5():
    binheap_0 = module_0.Binheap()
    assert f'{type(binheap_0).__module__}.{type(binheap_0).__qualname__}' == 'binheap.Binheap'
    assert binheap_0.container == [None]
    with pytest.raises(IndexError):
        binheap_0.pop()

def test_case_6():
    binheap_0 = module_0.Binheap()
    assert f'{type(binheap_0).__module__}.{type(binheap_0).__qualname__}' == 'binheap.Binheap'
    assert binheap_0.container == [None]
    var_0 = binheap_0.push(binheap_0)
    var_1 = binheap_0.display()

def test_case_7():
    bytes_0 = b'5\x9a'
    binheap_0 = module_0.Binheap(bytes_0)
    assert f'{type(binheap_0).__module__}.{type(binheap_0).__qualname__}' == 'binheap.Binheap'
    assert binheap_0.container == [None, 154, 53]
    var_0 = binheap_0.display()
    assert var_0 == ' 154 \n53 \n'

def test_case_8():
    binheap_0 = module_0.Binheap()
    assert f'{type(binheap_0).__module__}.{type(binheap_0).__qualname__}' == 'binheap.Binheap'
    assert binheap_0.container == [None]
    var_0 = binheap_0.display()
    assert var_0 == ''
