#Pyguin test cases converted from dijkstras/WHOLE_SUITE/seed_1706/test_dijkstras.py
import pytest
import dijkstras as module_0
import builtins as module_1

def test_case_0():
    bool_0 = False

def test_case_1():
    none_type_0 = None

def test_case_2():
    bool_0 = False

def test_case_3():
    str_0 = 'K\x0cqAzX'
    str_1 = 'di\x0bi^{X{g7N\\.[p)s\r'
    dict_0 = {str_0: str_0, str_1: str_1}

def test_case_4():
    bool_0 = True
    none_type_0 = None

def test_case_5():
    list_0 = []
    tuple_0 = (list_0, list_0)
    none_type_0 = None

def test_case_6():
    set_0 = set()

def test_case_7():
    str_0 = 'g'
