#Pyguin test cases converted from dijkstras/MIO/seed_1706/test_dijkstras.py
import pytest
import builtins as module_0
import dijkstras as module_1

def test_case_0():
    object_0 = module_0.object()
