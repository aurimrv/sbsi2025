#Pyguin test cases converted from dijkstras/MOSA/seed_1706/test_dijkstras.py
import pytest
import dijkstras as module_0

def test_case_0():
    int_0 = 2627
