#Pyguin test cases converted from trie/WHOLE_SUITE/seed_1706/test_trie.py
import pytest
import trie as module_0

def test_case_0():
    str_0 = 'Q0.@QmfFrl$LHU5'
    trie_0 = module_0.Trie(str_0)
    assert trie_0.head == {'Q': {'__eof__': '__eof__'}, '0': {'__eof__': '__eof__'}, '.': {'__eof__': '__eof__'}, '@': {'__eof__': '__eof__'}, 'm': {'__eof__': '__eof__'}, 'f': {'__eof__': '__eof__'}, 'F': {'__eof__': '__eof__'}, 'r': {'__eof__': '__eof__'}, 'l': {'__eof__': '__eof__'}, '$': {'__eof__': '__eof__'}, 'L': {'__eof__': '__eof__'}, 'H': {'__eof__': '__eof__'}, 'U': {'__eof__': '__eof__'}, '5': {'__eof__': '__eof__'}}
    assert module_0.Trie.eof == '__eof__'
    float_0 = -1670.63607
    list_0 = [str_0, str_0, float_0]
    trie_1 = module_0.Trie(str_0)
    assert trie_1.head == {'Q': {'__eof__': '__eof__'}, '0': {'__eof__': '__eof__'}, '.': {'__eof__': '__eof__'}, '@': {'__eof__': '__eof__'}, 'm': {'__eof__': '__eof__'}, 'f': {'__eof__': '__eof__'}, 'F': {'__eof__': '__eof__'}, 'r': {'__eof__': '__eof__'}, 'l': {'__eof__': '__eof__'}, '$': {'__eof__': '__eof__'}, 'L': {'__eof__': '__eof__'}, 'H': {'__eof__': '__eof__'}, 'U': {'__eof__': '__eof__'}, '5': {'__eof__': '__eof__'}}
    var_0 = trie_1.add(list_0)
    assert len(trie_1.head) == 15

def test_case_1():
    bytes_0 = b'\x94A\xf5\xde\xe1\x18\xfe\x9a\x92\xcd\nko6\xe7hyA\xc7'

def test_case_2():
    str_0 = 'G'
    trie_0 = module_0.Trie(str_0)
    assert trie_0.head == {'G': {'__eof__': '__eof__'}}
    assert module_0.Trie.eof == '__eof__'
    var_0 = trie_0.get_all_common_prefix(str_0)

def test_case_3():
    str_0 = ':h'
    trie_0 = module_0.Trie(str_0)
    assert trie_0.head == {':': {'__eof__': '__eof__'}, 'h': {'__eof__': '__eof__'}}
    assert module_0.Trie.eof == '__eof__'
    var_0 = trie_0.get_all_common_prefix(str_0)

def test_case_4():
    list_0 = []
    bool_0 = True
    bytes_0 = b'\xd32\xc6\x8d\x05x}\xfaja\xa1\xd3\xab\xe3\xceP\xd9'
    trie_0 = module_0.Trie(list_0)
    assert module_0.Trie.eof == '__eof__'
    var_0 = trie_0.get_all_common_prefix(list_0)
    var_1 = trie_0.get_all_common_prefix(bytes_0)

def test_case_5():
    str_0 = '*u<h)cDhLT@}+'
    list_0 = [str_0, str_0, str_0, str_0]
    str_1 = 'dO?LfY\t}Y%'
    str_2 = ')jaR'
    trie_0 = module_0.Trie(str_2)
    assert trie_0.head == {')': {'__eof__': '__eof__'}, 'j': {'__eof__': '__eof__'}, 'a': {'__eof__': '__eof__'}, 'R': {'__eof__': '__eof__'}}
    assert module_0.Trie.eof == '__eof__'
    var_0 = trie_0.add(str_1)
    assert len(trie_0.head) == 5

def test_case_6():
    float_0 = 1607.018248

def test_case_7():
    bytes_0 = b''
    str_0 = ')("x,{;U$(CWt/'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    tuple_0 = (dict_0,)
    trie_0 = module_0.Trie(tuple_0)
    assert trie_0.head == {')("x,{;U$(CWt/': {'__eof__': '__eof__'}}
    assert module_0.Trie.eof == '__eof__'
