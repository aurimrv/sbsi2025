#Pyguin test cases converted from radixsort/MIO/seed_1706/test_radixsort.py
import pytest
import radixsort as module_0

def test_case_0():
    int_0 = 201
    list_0 = [int_0, int_0, int_0]
    var_0 = module_0.radixsort(list_0)

def test_case_1():
    bool_0 = False
    list_0 = [bool_0]
    var_0 = module_0.radixsort(list_0)

def test_case_2():
    str_0 = '8."Y`pi"R0Wo^~'
