#Pyguin test cases converted from radixsort/WHOLE_SUITE/seed_1706/test_radixsort.py
import pytest
import radixsort as module_0

def test_case_0():
    bool_0 = False

def test_case_1():
    bool_0 = False
    list_0 = [bool_0, bool_0]
    var_0 = module_0.radixsort(list_0)

def test_case_2():
    str_0 = 'XoSR|=+|Z+:fTX'
    list_0 = []

def test_case_3():
    pass

def test_case_4():
    dict_0 = {}
    list_0 = [dict_0]

def test_case_5():
    bytes_0 = b'M\x8afG>!\x836\xed\x9b'
    var_0 = module_0.radixsort(bytes_0)
    none_type_0 = None
