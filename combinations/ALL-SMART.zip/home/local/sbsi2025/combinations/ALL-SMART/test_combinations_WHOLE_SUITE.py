#Pyguin test cases converted from combinations/WHOLE_SUITE/seed_1706/test_combinations.py
import pytest
import combinations as module_0

def test_case_0():
    str_0 = 'l(~Sg'
    var_0 = module_0.combinations_of_word(str_0)
    str_1 = "53j\n+[E|'VEuLE"

def test_case_1():
    str_0 = 'b7$u~f:OLV9$H]{'

def test_case_2():
    str_0 = '41XH'
    var_0 = module_0.combinations_of_phone_input(str_0)
    var_1 = module_0.combinations_of_phone_input(str_0)
    none_type_0 = None

def test_case_3():
    bytes_0 = b'ibz\x175<\t\x99(5C\x96h]^\x14'
    var_0 = module_0.combinations_of_word(bytes_0)
    var_1 = module_0.combinations_of_word(bytes_0)

def test_case_4():
    str_0 = 'G|X7P+: sB'
