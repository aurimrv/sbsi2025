import os
import sys
module_dir = os.path.dirname(os.path.abspath(__file__))
project_dir = os.path.abspath(os.path.join(module_dir, '..'))
sys.path.append(project_dir)

from dll import Node, DoubleLinkedList

import pytest

# Testing Node class
def test_node_init():
    node = Node(5)
    assert node.data == 5
    assert node.next is None
    assert node.prev is None

def test_node_repr():
    node = Node(10)
    assert repr(node) == "Value: 10"


# Testing DoubleLinkedList class
def test_dll_init_empty():
    dll = DoubleLinkedList()
    assert dll.head is None
    assert dll.tail is None
    assert dll._length == 0

def test_dll_init_with_data():
    dll = DoubleLinkedList([1, 2, 3])
    assert dll.head.data == 3
    assert dll.tail.data == 1
    assert dll._length == 3

def test_dll_push():
    dll = DoubleLinkedList()
    dll.push(7)
    assert dll.head.data == 7
    assert dll.tail.data == 7

def test_dll_pop():
    dll = DoubleLinkedList([4, 5, 6])
    popped = dll.pop()
    assert popped == 6
    assert dll.head.data == 5
    assert dll.tail.data == 4

def test_dll_append():
    dll = DoubleLinkedList()
    dll.append(3)
    assert dll.head.data == 3
    assert dll.tail.data == 3

def test_dll_shift():
    dll = DoubleLinkedList(['a', 'b', 'c'])
    shifted = dll.shift()
    assert shifted == 'a'
    assert dll.head.data == 'c'
    assert dll.tail.data == 'b'

def test_dll_remove():
    dll = DoubleLinkedList([1, 2, 3, 4])
    dll.remove(2)
    assert dll.head.data == 4
    assert dll.tail.data == 1
    assert dll._length == 3

def test_dll_remove_nonexistent():
    dll = DoubleLinkedList([1, 2, 3])
    with pytest.raises(ValueError):
        dll.remove(4)