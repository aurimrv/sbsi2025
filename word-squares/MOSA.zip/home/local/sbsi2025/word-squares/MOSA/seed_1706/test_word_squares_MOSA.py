#Pyguin test cases converted from word-squares/MOSA/seed_1706/test_word_squares.py
import pytest
import word_squares as module_0
import trie as module_1

def test_case_0():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0]

def test_case_1():
    str_0 = 'GCr(>EDUGS?k8 nE'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = module_0.word_squares(dict_0)
    trie_0 = module_1.Trie(var_0)
    assert trie_0.head == {}
    var_1 = module_0.word_squares(str_0)

def test_case_2():
    none_type_0 = None

def test_case_3():
    bytes_0 = b'\xadP@\xd6\x1dT\x95!\xeb\x840'
    str_0 = "AA' IH8ECj&ZW"
    list_0 = [str_0]
    var_0 = module_0.word_squares(list_0)
