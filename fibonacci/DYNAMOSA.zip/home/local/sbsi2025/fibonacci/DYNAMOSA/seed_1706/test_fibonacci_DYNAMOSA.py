#Pyguin test cases converted from fibonacci/DYNAMOSA/seed_1706/test_fibonacci.py
import pytest
import fibonacci as module_0

def test_case_0():
    bool_0 = False
    var_0 = module_0.fibonacci_dp(bool_0)
    assert var_0 == 0

def test_case_1():
    float_0 = 1165.0

def test_case_2():
    bool_0 = False
    var_0 = module_0.fibonacci_dp(bool_0)
    assert var_0 == 0
    int_0 = -175
    var_1 = module_0.fibonacci_recursive(int_0)
    assert var_1 == 0
    var_2 = module_0.fibonacci_recursive(var_1)
    assert var_2 == 0

def test_case_3():
    int_0 = 2014

def test_case_4():
    none_type_0 = None

def test_case_5():
    int_0 = -282
    var_0 = module_0.fibonacci_dp(int_0)
    assert var_0 == 0
    int_1 = 1588
    int_2 = 1045
    var_1 = module_0.fibonacci_dp(int_2)
    assert var_1 == 110305980418025610855325972157059252373735481295973772028824040497301889348212294548928366951224238807693996709091947986173076021428690937196504572322484831369437296091016913350023868800328158791689100428199535714763545

def test_case_6():
    bool_0 = True
    var_0 = module_0.fibonacci_dp(bool_0)
    assert var_0 == 1
    bool_1 = True
    bool_2 = False
    var_1 = module_0.fibonacci_recursive(bool_2)
    assert var_1 == 0
    var_2 = module_0.fibonacci_recursive(bool_1)
    assert var_2 is True
